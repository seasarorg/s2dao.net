using System;
using System.Text;
using Seasar.Dao.Attrs;

namespace Seasar.Dao.Tests.Dbms
{
    [Table("EMP2")]
    public class Employee
    {
        private int empno;
        private string ename;
        private short deptnum;

        public Employee()
        {
        }

        public int Empno
        {
            set { empno = value; }
            get { return empno; }
        }

        public string Ename
        {
            set { ename = value; }
            get { return ename; }
        }

        public short Deptnum
        {
            set { deptnum = value; }
            get { return deptnum; }
        }

        public override string ToString()
        {
            StringBuilder buf = new StringBuilder(50);
            buf.Append("Empno=");
            buf.Append(Empno);
            buf.Append(", Ename=");
            buf.Append(Ename);
            buf.Append(", Deptnum=");
            buf.Append(Deptnum);
            return buf.ToString();
        }

    }
}
