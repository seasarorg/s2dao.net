using System;
using System.Data;
using Seasar.Dao.Impl;
using Seasar.Dao.Dbms;
using Seasar.Extension.ADO;
using Seasar.Extension.ADO.Impl;
using Seasar.Framework.Util;
using NUnit.Framework;

namespace Seasar.Dao.Tests.Dbms
{

    /// <summary>
    /// MSSQLServerTest �̊T�v�̐����ł��B
    /// </summary>
    [TestFixture]
	public class DbmsManagerTest {

        [Test]
        public void TestCreateAutoSelectList() 
        {
            //String�����̎����Ȃ�
			//Assert.IsNotNull(DbmsManager.getDbms(""),"1");
			//Assert.IsNotNull(DbmsManager.getDbms("HSQL Database Engine"),"2");

            DataProvider sqlClient = new DataProvider();
            sqlClient.ConnectionType = "System.Data.SqlClient.SqlConnection";
            sqlClient.CommandType = "System.Data.SqlClient.SqlCommand";
            sqlClient.ParameterType = "System.Data.SqlClient.SqlParameter";
            sqlClient.DataAdapterType = "System.Data.SqlClient.SqlDataAdapter";
            IDataSource dataSource = new DataSourceImpl(sqlClient,"Server=127.0.0.1;database=s2dotnetdemo;Password=demopass;User ID=demouser");
            Assert.IsNotNull(DbmsManager.GetDbms(dataSource),"3");
            
            IDbConnection cn = DataSourceUtil.GetConnection(dataSource);
            Assert.IsNotNull(DbmsManager.GetDbms(dataSource,cn),"4");


		}
	}
}