using System;
using System.Collections;

namespace Seasar.Extension.ADO
{
    public interface IDatabaseMetaData
    {
        IList GetPrimaryKeySet(string tableName);
        IList GetTableSet();
        IList GetColumnSet(string tableName);
    }
}
