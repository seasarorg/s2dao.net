using System;
using System.Reflection;

namespace Seasar.Extension.ADO
{
    public interface IPropertyType
    {
        PropertyInfo PropertyInfo { get; }
        IValueType ValueType { get; }
        string PropertyName { get; }
        string ColumnName { get; set; }
        bool IsPrimaryKey { get; set; }
        bool IsPersistent { get; set; }
    }
}
