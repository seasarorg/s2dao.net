using System;
using System.Data;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO
{
    public interface IDataReaderFactory
    {
        IDataReader CreateDataReader(IDataSource dataSource, IDbCommand cmd);
    }
}
