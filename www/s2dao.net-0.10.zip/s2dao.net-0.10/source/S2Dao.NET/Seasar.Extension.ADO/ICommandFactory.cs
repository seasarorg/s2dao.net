using System;
using System.Data;

namespace Seasar.Extension.ADO
{
    public interface ICommandFactory
    {
        IDbCommand CreateCommand(IDbConnection con, string sql);
    }
}
