using System;
using Seasar.Framework.Exceptions;

namespace Seasar.Extension.ADO
{
    public interface IUpdateHandler
    {
        int Execute(object[] args);

        int Execute(object[] args, Type[] argTypes, string[] argNames);
    }
}
