using System;

namespace Seasar.Extension.ADO
{
    public interface ISelectHandler
    {
        object Execute(object[] args);
        object Execute(object[] args, Type[] argTypes, string[] argNames);
    }
}
