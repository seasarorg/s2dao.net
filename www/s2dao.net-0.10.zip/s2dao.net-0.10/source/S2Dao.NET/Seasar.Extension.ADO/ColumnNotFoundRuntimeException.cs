using System;
using Seasar.Framework.Exceptions;

namespace Seasar.Extension.ADO
{
    public class ColumnNotFoundRuntimeException : SRuntimeException
    {
        private string tableName;
        private string columnName;

        public ColumnNotFoundRuntimeException(string tableName, string columnName)
            : base("ESSR0068", new object[] { tableName, columnName })
        {
            this.tableName = tableName;
            this.columnName = columnName;
        }

        public string TableName
        {
            get { return tableName; }
        }

        public string ColumnName
        {
            get { return columnName; }
        }
    }
}
