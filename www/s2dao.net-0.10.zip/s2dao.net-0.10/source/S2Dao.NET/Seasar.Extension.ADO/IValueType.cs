using System;
using System.Data;

namespace Seasar.Extension.ADO
{
    public interface IValueType
    {
        object GetValue(IDataReader reader, int index);
        object GetValue(IDataReader reader, string columnName);
        void BindValue(IDbCommand cmd, string columnName, object value);
    }
}
