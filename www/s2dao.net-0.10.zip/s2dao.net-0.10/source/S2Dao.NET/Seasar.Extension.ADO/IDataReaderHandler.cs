using System;
using System.Data;

namespace Seasar.Extension.ADO
{
    public interface IDataReaderHandler
    {
        object Handle(IDataReader dataReader);
    }
}
