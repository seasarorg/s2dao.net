using System;
using Seasar.Framework.Exceptions;

namespace Seasar.Dao
{
    public class DaoNotFoundRuntimeException : SRuntimeException
    {
        private Type targetType;

        public DaoNotFoundRuntimeException(Type targetType)
            : base("EDAO0008", new object[] { targetType.Name })
        {
            this.targetType = targetType;
        }

        public Type TargetType
        {
            get { return this.targetType; }
        }
    }

    public class EndCommentNotFoundRuntimeException : SRuntimeException
    {
        public EndCommentNotFoundRuntimeException()
            : base("EDAO0007")
        {
        }
    }

    public class IfConditionNotFoundRuntimeException : SRuntimeException
    {
        public IfConditionNotFoundRuntimeException()
            : base("EDAO0004")
        {
        }
    }

    public class IllegalBoolExpressionRuntimeException : SRuntimeException
    {
        private string expression;

        public IllegalBoolExpressionRuntimeException(string expression)
            : base("EDAO0003", new object[] {expression})
        {
            this.expression = expression;
        }

        public string Expression
        {
            get { return this.expression; }
        }
    }

    public class IllegalSignatureRuntimeException : SRuntimeException
    {
        private string signature;

        public IllegalSignatureRuntimeException(string messageCode, string signature)
            : base(messageCode, new object[] { signature })
        {
            this.signature = signature;
        }

        public string Signature
        {
            get { return this.signature; }
        }
    }

    public class UpdateFailureRuntimeException : SRuntimeException
    {
        private object bean;
        private int rows;

        public UpdateFailureRuntimeException(object bean, int rows)
            : base("EDAO0005", new object[] { bean.ToString(), rows.ToString() })
        {
            this.bean = bean;
            this.rows = rows;
        }

        public object Bean
        {
            get { return this.bean; }
        }

        public int Rows
        {
            get { return this.rows; }
        }
    }

    public class NotSingleRowUpdatedRuntimeException : UpdateFailureRuntimeException
    {
        public NotSingleRowUpdatedRuntimeException(object bean, int rows)
            : base(bean, rows)
        {
        }
    }

    public class PrimaryKeyNotFoundRuntimeException : SRuntimeException
    {
        private Type targetType;

        public PrimaryKeyNotFoundRuntimeException(Type targetType)
            : base("EDAO0009", new object[] { targetType.Name })
        {
            this.targetType = targetType;
        }

        public Type TargetType
        {
            get { return this.targetType; }
        }
    }

    public class TokenNotClosedRuntimeException : SRuntimeException
    {
        private string token;
        private string sql;

        public TokenNotClosedRuntimeException(string token, string sql)
            : base("EDAO0002", new object[] { token, sql })
        {
            this.token = token;
            this.sql = sql;
        }

        public string Token
        {
            get { return this.token; }
        }

        public string Sql
        {
            get { return this.sql; }
        }
    }
}
