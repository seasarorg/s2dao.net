using System;

namespace Seasar.Dao
{
    public interface IDaoMetaDataFactory
    {
        IDaoMetaData GetDaoMetaData(Type daoType);
    }
}
