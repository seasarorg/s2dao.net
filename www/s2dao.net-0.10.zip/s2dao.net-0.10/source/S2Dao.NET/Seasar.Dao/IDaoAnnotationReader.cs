using System;

namespace Seasar.Dao
{
    public interface IDaoAnnotationReader
    {
        string GetQuery(string name);
        Type GetBeanType();
        string[] GetNoPersistentProps(string methodName);
        string[] GetPersistentProps(string methodName);
        string GetSql(string name, IDbms dbms);
    }
}
