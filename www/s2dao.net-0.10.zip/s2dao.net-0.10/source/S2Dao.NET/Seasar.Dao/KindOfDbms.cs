using System;

namespace Seasar.Dao
{
    public enum KindOfDbms
    {
        None, 
        MSSQLServer
    }
}
