using System;

namespace Seasar.Dao
{
    public interface ISqlCommand 
    {
        object Execute(object[] args);
    }    
}
