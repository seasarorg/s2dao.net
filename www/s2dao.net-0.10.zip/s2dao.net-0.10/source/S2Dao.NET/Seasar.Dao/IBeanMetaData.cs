using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao
{
    public interface IBeanMetaData : IDtoMetaData
    {
        string TableName { get; }
        IPropertyType VersionNoPropertyType { get; }
        string VersionNoPropertyName { get; }
        bool HasVersionNoPropertyType { get; }
        IPropertyType TimestampPropertyType { get; }
        string TimestampPropertyName { get; }
        bool HasTimestampPropertyType { get; }
        string ConvertFullColumnName(string alias);
        IPropertyType GetPropertyTypeByAliasName(string aliasName);
        IPropertyType GetPropertyTypeByColumnName(string columnName);
        bool HasPropertyTypeByColumnName(string columnName);
        bool HasPropertyTypeByAliasName(string aliasName);
        int RelationPropertyTypeSize{ get; }
        IRelationPropertyType GetRelationPropertyType(int index);
        IRelationPropertyType GetRelationPropertyType(string propertyName);
        int PrimaryKeySize { get; }
        string GetPrimaryKey(int index);
        IIdentifierGenerator IdentifierGenerator { get; }
        string AutoSelectList { get; }
        bool IsRelation { get; }
    }
}
