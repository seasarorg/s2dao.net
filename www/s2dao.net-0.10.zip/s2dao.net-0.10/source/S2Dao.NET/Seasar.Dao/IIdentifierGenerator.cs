using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao
{
    public interface IIdentifierGenerator
    {
        bool IsSelfGenerate{ get; }
        void SetIdentifier(object bean, IDataSource ds);
    }
}
