using System;

namespace Seasar.Dao
{
    public interface IDaoMetaData
    {
        Type BeanType { get; }
        IBeanMetaData BeanMetaData { get; }
        bool HasSqlCommand(string methodName);
        ISqlCommand GetSqlCommand(string methodName);
        ISqlCommand CreateFindCommand(string query);
        ISqlCommand CreateFindArrayCommand(string query);
        ISqlCommand CreateFindBeanCommand(string query);
        ISqlCommand CreateFindObjectCommand(string query);
    }
}
