using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao
{
    public interface IDbms
    {
        string GetAutoSelectSql(IBeanMetaData beanMetaData);
        string Suffix { get; }
        string IdentitySelectString { get; }
        string GetSequenceNextValString(string sequenceName);
        KindOfDbms Dbms { get; }
        IDatabaseMetaData DatabaseMetaData { get; }
    }
}
