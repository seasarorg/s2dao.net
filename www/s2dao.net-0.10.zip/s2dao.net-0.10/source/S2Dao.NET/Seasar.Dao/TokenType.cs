using System;

namespace Seasar.Dao
{
    public enum TokenType
    {
        SQL,
        COMMENT,
        ELSE,
        BIND_VARIABLE,
        EOF
    }
}
