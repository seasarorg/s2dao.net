using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao
{
    public interface IRelationPropertyType : IPropertyType
    {
        int RelationNo { get; }
        int KeySize { get; }
        string GetMyKey(int index);
        string GetYourKey(int index);
        bool IsYourKey(string columnName);
        IBeanMetaData BeanMetaData { get; }
    }
}
