using System;

namespace Seasar.Dao
{
    public interface ISqlParser
    {
        INode Parse();
    }
}
