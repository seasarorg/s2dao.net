using System;

namespace Seasar.Dao
{
    public interface ICommandContext
    {
        object GetArg(string name);
        Type GetArgType(string name);
        void AddArg(string name, object arg, Type argType);
        string Sql { get; }
        object[] BindVariables { get; }
        Type[] BindVariableTypes { get; }
        string[] BindVariableNames { get; }
        ICommandContext AddSql(string sql);
        ICommandContext AddSql(string sql, object bindVariable, Type bindVariableType, string bindVariableName);
        ICommandContext AddSql(object bindVariable, Type bindVariableType, string bindVariableName);
        ICommandContext AddSql(string sql, object[] bindVariables, Type[] bindVariableTypes, string[] bindVariableNames);
        ICommandContext AppendSql(object bindVariable, Type bindVariableType, string bindVariableName);
        bool IsEnabled { get; set; }
    }
}
