using System;

namespace Seasar.Dao
{
    public interface ISqlTokenizer
    {
        string Token { get; }
        string Before { get; }
        string After { get; }
        int Position { get; }
        TokenType TokenType { get; }
        TokenType NextTokenType { get; }
        TokenType Next();
        string SkipToken();
        string SkipWhitespace();

    }
}
