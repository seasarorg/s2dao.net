using System;
using System.Collections;
using Seasar.Dao.Node;
using Seasar.Framework.Util;

namespace Seasar.Dao.Parser
{
    public class SqlParserImpl : ISqlParser
    {
        private ISqlTokenizer tokenizer;
        private Stack nodeStack = new Stack();

        public SqlParserImpl(string sql)
        {
            sql = sql.Trim();
            if (sql.EndsWith(";"))
            {
                sql = sql.Substring(0, sql.Length - 1);
            }
            tokenizer = new SqlTokenizerImpl(sql);
        }

        public INode Parse()
        {
            Push(new ContainerNode());
            while (TokenType.EOF != tokenizer.Next())
            {
                ParseToken();
            }
            return Pop();
        }

        protected void ParseToken()
        {
            switch (tokenizer.TokenType)
            {
                case TokenType.SQL:
                    ParseSql();
                    break;
                case TokenType.COMMENT:
                    ParseComment();
                    break;
                case TokenType.ELSE:
                    ParseElse();
                    break;
                case TokenType.BIND_VARIABLE:
                    ParseBindVariable();
                    break;
            }
        }

        protected void ParseSql()
        {
            string sql = tokenizer.Token;
            if (IsElseMode())
            {
                sql = sql.Replace("--", "");
            }
            INode node = Peek();

            if ( (node is IfNode || node is ElseNode) && node.ChildSize == 0)
            {
                ISqlTokenizer st = new SqlTokenizerImpl(sql);
                st.SkipWhitespace();
                string token = st.SkipToken();
                st.SkipWhitespace();
                if ("AND".Equals(token.ToUpper()) || "OR".Equals(token.ToUpper()))
                {
                    node.AddChild(new PrefixSqlNode(st.Before, st.After));
                }
                else
                {
                    node.AddChild(new SqlNode(sql));
                }
            }
            else
            {
                node.AddChild(new SqlNode(sql));
            }
        }

        protected void ParseComment()
        {
            string comment = tokenizer.Token;
            if (IsTargetComment(comment))
            {
                if (IsIfComment(comment))
                {
                    ParseIf();
                }
                else if (IsBeginComment(comment))
                {
                    ParseBegin();
                }
                else if (IsEndComment(comment))
                {
                    return;
                }
                else
                {
                    ParseCommentBindVariable();
                }
            }
        }

        protected void ParseIf()
        {
            string condition = tokenizer.Token.Substring(2).Trim();
            if (StringUtil.IsEmpty(condition))
            {
                throw new IfConditionNotFoundRuntimeException();
            }
            IfNode ifNode = new IfNode(condition);
            Peek().AddChild(ifNode);
            Push(ifNode);
            ParseEnd();
        }

        protected void ParseBegin()
        {
            BeginNode beginNode = new BeginNode();
            Peek().AddChild(beginNode);
            Push(beginNode);
            ParseEnd();
        }

        protected void ParseEnd()
        {
            while (TokenType.EOF != tokenizer.Next())
            {
                if (tokenizer.TokenType == TokenType.COMMENT
                    && IsEndComment(tokenizer.Token))
                {
                    Pop();
                    return;
                }
                ParseToken();
            }
            throw new EndCommentNotFoundRuntimeException();
        }

        protected void ParseElse()
        {
            INode parent = Peek();
            if ( !(parent is IfNode) )
            {
                return;
            }
            IfNode ifNode = (IfNode) Pop();
            ElseNode elseNode = new ElseNode();
            ifNode.ElseNode = elseNode;
            Push(elseNode);
            tokenizer.SkipWhitespace();
        }

        protected void ParseCommentBindVariable()
        {
            string expr = tokenizer.Token;
            string s = tokenizer.SkipToken();
            if (s.StartsWith("(") && s.EndsWith(")"))
            {
                Peek().AddChild(new ParenBindVariableNode(expr));
            }
            else if (expr.StartsWith("$"))
            {
                Peek().AddChild(new EmbeddedValueNode(expr.Substring(1)));
            }
            else
            {
                Peek().AddChild(new BindVariableNode(expr));
            }
        }

        protected void ParseBindVariable()
        {
            string expr = tokenizer.Token;
            Peek().AddChild(new BindVariableNode(expr));
        }

        protected INode Pop()
        {
            return (INode) nodeStack.Pop();
        }

        protected INode Peek()
        {
            return (INode) nodeStack.Peek();
        }

        protected void Push(INode node)
        {
            nodeStack.Push(node);
        }

        protected bool IsElseMode()
        {
            for (int i = 0; i < nodeStack.Count; ++i)
            {
                if (nodeStack.ToArray()[i] is ElseNode)
                {
                    return true;
                }
            }
            return false;
        }

        private static bool IsTargetComment(string comment)
        {
            return comment != null && comment.Length > 0
                && IsCSharpIdentifierStart(comment.ToCharArray()[0]);
        }
        
        private static bool IsCSharpIdentifierStart(Char c)
        {
            return Char.IsLetterOrDigit(c) || c == '_' || c == '\\' || c == '$' || c == '@';
        }

        private static bool IsIfComment(string comment)
        {
            return comment.StartsWith("IF");
        }

        private static bool IsBeginComment(string content)
        {
            return content != null && "BEGIN".Equals(content);
        }

        private static bool IsEndComment(string content)
        {
            return content != null && "END".Equals(content);
        }
    }
}
