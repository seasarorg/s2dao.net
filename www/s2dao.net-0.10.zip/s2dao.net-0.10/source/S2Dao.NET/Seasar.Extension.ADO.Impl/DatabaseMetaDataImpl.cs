using System;
using System.Collections;

namespace Seasar.Extension.ADO.Impl
{
    public class DatabaseMetaDataImpl : IDatabaseMetaData
    {
        private IList tableSet;
        private IDictionary primaryKeys;
        private IDictionary columns;

        public DatabaseMetaDataImpl()
        {
        }

        public IList TableSet
        {
            set { tableSet = value; }
        }

        public IDictionary PrimaryKeys
        {
            set { primaryKeys = value; }
        }

        public IDictionary Columns
        {
            set { columns = value; }
        }

        #region IDatabaseMetaData �����o

        public System.Collections.IList GetPrimaryKeySet(string tableName)
        {
            return (IList) primaryKeys[tableName];
        }

        public IList GetTableSet()
        {
            return tableSet;
        }

        public IList GetColumnSet(string tableName)
        {
            return (IList) columns[tableName];
        }

        #endregion
    }
}
