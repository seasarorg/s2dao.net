using System;
using Seasar.Extension.ADO;
using Seasar.Framework.Util;

namespace Seasar.Extension.ADO.Impl
{
    public class BasicDataReaderFactory : IDataReaderFactory
    {
        public readonly static IDataReaderFactory INSTANCE = new BasicDataReaderFactory();

        public BasicDataReaderFactory()
        {
        }

        #region IDataReaderFactory �����o

        public System.Data.IDataReader CreateDataReader(IDataSource dataSource, System.Data.IDbCommand cmd)
        {
            return CommandUtil.ExecuteReader(dataSource, cmd);
        }

        #endregion
    }
}
