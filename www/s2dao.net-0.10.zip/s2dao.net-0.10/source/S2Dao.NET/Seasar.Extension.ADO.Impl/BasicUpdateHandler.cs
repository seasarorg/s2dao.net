using System;
using System.Data;
using Seasar.Extension.ADO;
using Seasar.Framework.Log;
using Seasar.Framework.Util;

namespace Seasar.Extension.ADO.Impl 
{
    public class BasicUpdateHandler : BasicHandler, IUpdateHandler
    {
        private static Logger logger = Logger.GetLogger(typeof(BasicUpdateHandler));

        public BasicUpdateHandler()
        {
        }

        public BasicUpdateHandler(IDataSource dataSource, string sql)
            : base(dataSource, sql)
        {
        }

        public BasicUpdateHandler(IDataSource dataSource, string sql,
            ICommandFactory commandFactory)
            : base(dataSource, sql, commandFactory)
        {
        }

        #region IUpdateHandler �����o

        public int Execute(object[] args)
        {
            return Execute(args, Type.GetTypeArray(args), new string[args.Length]);
        }

        public int Execute(object[] args, Type[] argTypes, string[] argNames)
        {
            if(logger.IsDebugEnabled)
                logger.Debug(GetCompleteSql(args));
            IDbConnection connection = Connection;
            try
            {
                return Execute(connection, args, argTypes, argNames);
            }
            finally
            {
                DataSourceUtil.CloseConnection(this.DataSource, connection);
            }
        }

        protected int Execute(IDbConnection connection, object[] args, Type[] argTypes,
            string[] argNames)
        {
            IDbCommand cmd = DataSource.GetCommand(Sql, connection);
            try
            {
                BindArgs(cmd, args, argTypes, argNames);
                return CommandUtil.ExecuteNonQuery(this.DataSource, cmd);
            }
            finally
            {
                CommandUtil.Close(cmd);
            }
        }

        #endregion
    }
}
