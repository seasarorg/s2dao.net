using System;
using Seasar.Framework.Util;

namespace Seasar.Extension.ADO.Impl
{
    public class BasicCommandFactory : ICommandFactory
    {
        public readonly static ICommandFactory INSTANCE = new BasicCommandFactory();

        #region ICommandFactory �����o

        public System.Data.IDbCommand CreateCommand(System.Data.IDbConnection con, string sql)
        {
            return ConnectionUtil.Command(con, sql);
        }

        #endregion
    }
}
