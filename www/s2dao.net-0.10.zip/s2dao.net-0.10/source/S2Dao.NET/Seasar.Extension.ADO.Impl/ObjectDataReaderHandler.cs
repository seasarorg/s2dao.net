using System;
using System.Data;
using Seasar.Extension.ADO.Types;

namespace Seasar.Extension.ADO.Impl
{
    public class ObjectDataReaderHandler : IDataReaderHandler
    {
        public ObjectDataReaderHandler()
        {
        }

        #region IDataReaderHandler �����o

        public object Handle(System.Data.IDataReader dataReader)
        {
//            if(dataReader.Read())
//            {
//                DataTable dataTable = dataReader.GetSchemaTable();
//                IValueType valueType = ValueTypes.GetValueType(dataTable.Rows[0]["DataType"]);
//                return valueType.GetValue(dataReader, 1);
//            }
//            else
//            {
//                return null;
//            }
            return null;
        }

        #endregion
    }
}
