using System;
using System.Reflection;
using Seasar.Extension.ADO.Types;

namespace Seasar.Extension.ADO.Impl
{
    public class PropertyTypeImpl : IPropertyType
    {
        private PropertyInfo propertyInfo;
        private string propertyName;
        private string columnName;
        private IValueType valueType;
        private bool primaryKey = false;
        private bool persistent = true;

        public PropertyTypeImpl(PropertyInfo propertyInfo)
            : this(propertyInfo, ValueTypes.OBJECT, propertyInfo.Name)
        {
        }

        public PropertyTypeImpl(PropertyInfo propertyInfo, IValueType valueType)
            : this(propertyInfo, valueType, propertyInfo.Name)
        {
        }

        public PropertyTypeImpl(PropertyInfo propertyInfo, IValueType valueType,
            string columnName)
        {
            this.propertyInfo = propertyInfo;
            this.propertyName = propertyInfo.Name;
            this.valueType  = valueType;
            this.columnName = columnName;
        }

        public PropertyTypeImpl(string propertyName, IValueType valueType)
        {
            this.propertyName = propertyName;
            this.valueType = valueType;
            this.columnName = propertyName;
        }

        #region IPropertyType �����o

        public System.Reflection.PropertyInfo PropertyInfo
        {
            get
            {
                return propertyInfo;
            }
        }

        public IValueType ValueType
        {
            get
            {
                return valueType;
            }
        }

        public string PropertyName
        {
            get
            {
                return propertyName;
            }
        }

        public string ColumnName
        {
            get
            {
                return columnName;
            }
            set
            {
                columnName = value;
            }
        }

        public bool IsPrimaryKey
        {
            get
            {
                return primaryKey;
            }
            set
            {
                primaryKey = value;
            }
        }

        public bool IsPersistent
        {
            get
            {
                return persistent;
            }
            set
            {
                persistent = value;
            }
        }

        #endregion
    }
}
