using System;

namespace Seasar.Dao.Context
{
    public class OleDbCommandContextImpl : AbstractCommandContext
    {
        public OleDbCommandContextImpl()
        {
        }

        public OleDbCommandContextImpl(ICommandContext parent) : base(parent)
        {    
        }

        public override ICommandContext AddSql(object bindVariable,
            Type bindVariableType, string bindVariableName) 
        {
            base.AddSql("?", bindVariable, bindVariableType, bindVariableName);        
            return this;
        }

        public override ICommandContext AppendSql(object bindVariable,
            Type bindVariableType, string bindVariableName) 
        {
            base.AddSql(", ?", bindVariable, bindVariableType, bindVariableName);        
            return this;
        }

    }
}
