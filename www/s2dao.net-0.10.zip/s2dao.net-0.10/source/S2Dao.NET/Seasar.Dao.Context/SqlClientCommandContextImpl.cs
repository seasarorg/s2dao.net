using System;

namespace Seasar.Dao.Context
{
    public class SqlClientCommandContextImpl : AbstractCommandContext
    {
        public SqlClientCommandContextImpl()
        {
        }

        public SqlClientCommandContextImpl(ICommandContext parent) : base(parent)
        {
        }

        public override ICommandContext AddSql(object bindVariable,
            Type bindVariableType, string bindVariableName)
        {
            base.AddSql("@" + bindVariableName, bindVariable, bindVariableType, bindVariableName);
            return this;
        }

        public override ICommandContext AppendSql(object bindVariable,
            Type bindVariableType, string bindVariableName)
        {
            base.AddSql(", @" + bindVariableName, bindVariable, bindVariableType, bindVariableName);
            return this;
        }
    }
}
