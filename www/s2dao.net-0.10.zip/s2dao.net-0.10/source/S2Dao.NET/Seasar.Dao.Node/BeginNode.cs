using System;

namespace Seasar.Dao.Node
{
    public class BeginNode : ContainerNode
    {
        public BeginNode()
        {
        }

        public override void Accept(ICommandContext ctx)
        {
            ICommandContext childCtx = GetCommandContext(ctx);
            base.Accept(childCtx);
            if(childCtx.IsEnabled)
            {
                ctx.AddSql(childCtx.Sql,childCtx.BindVariables,
                    childCtx.BindVariableTypes, childCtx.BindVariableNames);
            }
        }

        private ICommandContext GetCommandContext(ICommandContext ctx)
        {
            return (ICommandContext) Activator.CreateInstance(
                ctx.GetType(), new object[] { ctx });
        }

    }
}
