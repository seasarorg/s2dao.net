using System;

namespace Seasar.Dao.Node
{
    public class PrefixSqlNode : AbstractNode
    {
        private string prefix;
        private string sql;

        public PrefixSqlNode(string prefix, string sql)
        {
            this.prefix = prefix;
            this.sql = sql;
        }

        public string Prefix
        {
            get { return prefix; }
        }

        public string Sql
        {
            get { return sql; }
        }

        public override void Accept(ICommandContext ctx)
        {
            if(ctx.IsEnabled) ctx.AddSql(prefix);
            ctx.AddSql(sql);
        }

    }
}
