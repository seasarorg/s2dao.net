using System;
using System.Reflection;

namespace Seasar.Dao.Node
{
    public class EmbeddedValueNode : AbstractNode
    {
        private string expression;
        private string baseName;
        private string propertyName;

        public EmbeddedValueNode(string expression)
        {
            this.expression = expression;
            string[] array = expression.Split(new char[] {','});
            baseName = array[0];
            if(array.Length > 1) propertyName = array[1];
        }

        public string Expression
        {
            get { return expression; }
        }

        public override void Accept(ICommandContext ctx)
        {
            object value = ctx.GetArg(baseName);
            Type type = ctx.GetArgType(baseName);
            if(propertyName != null)
            {
                PropertyInfo pi = type.GetProperty(propertyName);
                value = pi.GetValue(value, null);
                type = pi.PropertyType;
            }
            if(value != null) ctx.AddSql(value.ToString());
        }

    }
}
