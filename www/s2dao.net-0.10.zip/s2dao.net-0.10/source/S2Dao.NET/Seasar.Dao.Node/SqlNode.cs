using System;

namespace Seasar.Dao.Node
{
    public class SqlNode : AbstractNode
    {
        private string sql;

        public SqlNode(string sql)
        {
            this.sql = sql;
        }

        public string Sql
        {
            get { return sql; }
        }

        public override void Accept(ICommandContext ctx)
        {
            ctx.AddSql(sql);
        }

    }
}
