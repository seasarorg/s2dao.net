using System;
using System.Collections;

namespace Seasar.Dao.Node
{
    public class ParenBindVariableNode : AbstractNode
    {
        private string bindName;
        private string expression;

        public ParenBindVariableNode(string expression)
        {
            this.bindName = expression;
            this.expression = "self.GetArg('" + expression + "')";
        }

        public string Expression
        {
            get { return expression; }
        }

        public override void Accept(ICommandContext ctx)
        {
            object var = InvokeExpression(expression, ctx);
            if(var != null)
            {
                IList list = var as IList;
                Array array = new object[list.Count];
                list.CopyTo(array, 0);
                BindArray(ctx, array);
            }
            else if(var == null)
            {
                return;
            }
            else if(var.GetType().IsArray)
            {
                BindArray(ctx, var);
            }
            else
            {
                ctx.AddSql(var, var.GetType(), bindName);
            }
        }

        private void BindArray(ICommandContext ctx, object arrayArg)
        {
            object[] array = arrayArg as object[];
            int length = array.Length;
            if(length == 0) return;
            Type type = null;
            for(int i = 0; i < length; ++i)
            {
                object o = array[i];
                if(o != null) type = o.GetType();
            }
            ctx.AddSql("(");
            ctx.AddSql(array[0], type, bindName + 1);
            for(int i = 1; i < length; ++i)
            {
                ctx.AppendSql(array[i], type, bindName + (i + 1));
            }
            ctx.AddSql(")");
        }

    }
}
