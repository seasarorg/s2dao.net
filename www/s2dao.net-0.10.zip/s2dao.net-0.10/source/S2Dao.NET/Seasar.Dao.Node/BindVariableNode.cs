using System;
using System.Reflection;

namespace Seasar.Dao.Node
{
    public class BindVariableNode : AbstractNode
    {
        private string expression;
        private string baseName;
        private string propertyName;

        public BindVariableNode(string expression)
        {
            this.expression = expression;
            string[] array = expression.Split('.');
            baseName = array[0];
            if (array.Length > 1) propertyName = array[1];
        }

        public string Expression
        {
            get { return expression; }
        }

        public override void Accept(ICommandContext ctx)
        {
            object value = ctx.GetArg(baseName);
            Type type = ctx.GetArgType(baseName);
            if(propertyName != null)
            {
                PropertyInfo pi = type.GetProperty(propertyName);
                value = pi.GetValue(value, null);
                type = pi.PropertyType;
            }
            ctx.AddSql(value, type, baseName);
        }

    }
}
