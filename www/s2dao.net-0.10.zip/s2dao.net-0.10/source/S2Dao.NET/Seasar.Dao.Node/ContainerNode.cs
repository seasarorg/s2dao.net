using System;

namespace Seasar.Dao.Node
{
    public class ContainerNode : AbstractNode
    {
        public ContainerNode()
        {
        }

        public override void Accept(ICommandContext ctx)
        {
            for(int i = 0; i < ChildSize; ++i)
            {
                GetChild(i).Accept(ctx);
            }
        }

    }
}
