using System;

namespace Seasar.Dao.Node
{
    public class IfNode : ContainerNode
    {
        private string expression;
        private ElseNode elseNode;
        private ExpressionUtil expressionUtil;
        
        public IfNode(string expression)
        {
			expressionUtil = new ExpressionUtil();
            this.expression = expressionUtil.parseExpression(expression);
            if (this.expression == null)
                throw new ApplicationException("IllegalBoolExpression=[" + this.expression + "]");
        }

        public string Expression
        {
            get { return this.expression; }
        }

        public ElseNode ElseNode
        {
            get { return elseNode; }
            set { elseNode = value; }
        }

        public override void Accept(ICommandContext ctx)
        {
            object result = InvokeExpression(this.expression, ctx);
            if (result != null)
            {
				if(Convert.ToBoolean(result))
				{
					base.Accept(ctx);
					ctx.IsEnabled = true;
				}
                else if (elseNode != null)
                {
                    elseNode.Accept(ctx);
                    ctx.IsEnabled = true;
                }
            }
            else
            {
                throw new ApplicationException("IllegalBoolExpression=[" + this.expression + "]");
            }
        }
    }
}
