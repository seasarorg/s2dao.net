using System;
using System.Collections;
using System.Text;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Dbms
{
    /// <summary>
    /// Standard �̊T�v�̐����ł��B
    /// </summary>
    public class Standard : IDbms
    {
        private Hashtable autoSelectFromClauseCache = new Hashtable();

        public Standard()
        {
        }

        public virtual string Suffix
        {
            get { return ""; }
        }

        public virtual KindOfDbms Dbms
        {
            get { return KindOfDbms.None; }
        }

        public  string GetAutoSelectSql(IBeanMetaData beanMetaData)
        {
            StringBuilder buf = new StringBuilder(100);
            buf.Append(beanMetaData.AutoSelectList);
            buf.Append(" ");
            string beanName = beanMetaData.BeanType.Name;
            lock(autoSelectFromClauseCache)
            {
                string fromClause = (string) autoSelectFromClauseCache[beanName];
                if(fromClause == null)
                {
                    fromClause = this.CreateAutoSelectFromClause(beanMetaData);
                    autoSelectFromClauseCache[beanName] = fromClause;
                }
                buf.Append(fromClause);
            }
            return buf.ToString();
        }

        protected string CreateAutoSelectFromClause(IBeanMetaData beanMetaData)
        {
            StringBuilder buf = new StringBuilder(100);
            buf.Append("FROM ");
            string myTableName = beanMetaData.TableName;
            buf.Append(myTableName);
            for(int i = 0; i < beanMetaData.RelationPropertyTypeSize; ++i)
            {
                IRelationPropertyType rpt = beanMetaData.GetRelationPropertyType(i);
                IBeanMetaData bmd = rpt.BeanMetaData;
                buf.Append(" LEFT OUTER JOIN ");
                buf.Append(bmd.TableName);
                buf.Append(" ");
                string yourAliasName = rpt.PropertyName;
                buf.Append(yourAliasName);
                buf.Append(" ON ");
                for(int j = 0; j < rpt.KeySize; ++j)
                {
                    buf.Append(myTableName);
                    buf.Append(".");
                    buf.Append(rpt.GetMyKey(j));
                    buf.Append(" = ");
                    buf.Append(yourAliasName);
                    buf.Append(".");
                    buf.Append(rpt.GetYourKey(j));
                    buf.Append(" AND ");
                }
                buf.Length = buf.Length - 5;
            }
            return buf.ToString();
        }

        public virtual string IdentitySelectString
        {
            get { return null; }
        }

        public string GetSequenceNextValString(string sequenceName)
        {
            return null;
        }

        public virtual IDatabaseMetaData DatabaseMetaData
        {
            get { return null; }
        }
    }
}
