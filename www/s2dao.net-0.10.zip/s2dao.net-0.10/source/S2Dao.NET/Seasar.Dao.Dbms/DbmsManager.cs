using System;
using System.Collections;
using System.Data;
using System.Globalization;
using System.Reflection;
using System.Resources;
using Seasar.Framework.Util;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Dbms
{
    public sealed class DbmsManager
    {
        private static ResourceManager resourceManager;

        static DbmsManager()
        {
            resourceManager = new ResourceManager(
                "Dbms", Assembly.GetExecutingAssembly());
        }

        private DbmsManager()
        {
        }

        public static IDbms GetDbms(IDataSource dataSource)
        {
            IDbms dbms = null;
            IDbConnection cn = DataSourceUtil.GetConnection(dataSource);
            try
            {
                dbms = GetDbms(dataSource, cn);
            }
            finally
            {
                DataSourceUtil.CloseConnection(dataSource, cn);
            }
            return dbms;
        }

        public static IDbms GetDbms(IDataSource dataSource, IDbConnection cn)
        {
            IDbms dbms = (IDbms) Activator.CreateInstance(Type.GetType(
                resourceManager.GetString(cn.GetType().Name)),
                new object[] { dataSource, cn });
            if(dbms == null)
                dbms = (IDbms) ClassUtil.NewInstance(Type.GetType(
                    resourceManager.GetString("")));
            return dbms;
        }
    }
}
