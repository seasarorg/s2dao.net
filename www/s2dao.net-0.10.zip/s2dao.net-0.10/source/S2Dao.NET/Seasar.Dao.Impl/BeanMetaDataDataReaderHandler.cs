using System;
using System.Collections;
using System.Data;
using System.Reflection;

namespace Seasar.Dao.Impl
{
    public class BeanMetaDataDataReaderHandler
        : AbstractBeanMetaDataDataReaderHandler
    {
        public BeanMetaDataDataReaderHandler(IBeanMetaData beanMetaData)
            : base(beanMetaData)
        {
        }

        public override object Handle(IDataReader dataReader)
        {
            if(dataReader.Read())
            {
                IList columnNames = CreateColumnNames(dataReader.GetSchemaTable());
                object row = CreateRow(dataReader, columnNames);
                for(int i = 0; i < BeanMetaData.RelationPropertyTypeSize; ++i)
                {
                    IRelationPropertyType rpt = BeanMetaData
                        .GetRelationPropertyType(i);
                    if(rpt == null) continue;
                    object relationRow = CreateRelationRow(dataReader, rpt,
                        columnNames, null);
                    if(relationRow != null)
                    {
                        PropertyInfo pi = rpt.PropertyInfo;
                        pi.SetValue(row, relationRow, null);
                    }
                }
                return row;
            }
            else
            {
                return null;
            }
        }

    }
}
