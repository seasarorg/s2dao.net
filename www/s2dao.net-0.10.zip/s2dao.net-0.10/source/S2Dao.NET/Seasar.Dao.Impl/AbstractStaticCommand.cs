using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public abstract class AbstractStaticCommand : AbstractSqlCommand
    {
        private IBeanMetaData beanMetaData;

        public AbstractStaticCommand(IDataSource dataSource,
            ICommandFactory commandFactory, IBeanMetaData beanMetaData)
            : base(dataSource, commandFactory)
        {
            this.beanMetaData = beanMetaData;
        }

        public IBeanMetaData BeanMetaData
        {
            get { return this.beanMetaData; }
        }
    }
}
