using System;
using System.Reflection;
using Seasar.Extension.ADO;
using Seasar.Extension.ADO.Impl;

namespace Seasar.Dao.Impl
{
    public class RelationPropertyTypeImpl 
        : PropertyTypeImpl, IRelationPropertyType
    {
        protected int relationNo;
        protected string[] myKeys;
        protected string[] yourKeys;
        protected IBeanMetaData beanMetaData;

        public RelationPropertyTypeImpl(PropertyInfo propertyInfo)
            : base(propertyInfo)
        {
        }

        public RelationPropertyTypeImpl(PropertyInfo propertyInfo, int relationNo,
            string[] myKeys, string[] yourKeys, IDatabaseMetaData dbMetaData, IDbms dbms)
            : base(propertyInfo)
        {
            this.relationNo = relationNo;
            this.myKeys = myKeys;
            this.yourKeys = yourKeys;
            Type beanType = propertyInfo.PropertyType;
            beanMetaData = new BeanMetaDataImpl(beanType, dbMetaData, dbms);
        }

        #region IRelationPropertyType �����o

        public int RelationNo
        {
            get
            {
                return relationNo;
            }
        }

        public int KeySize
        {
            get
            {
                if(myKeys.Length > 0)
                    return myKeys.Length;
                else
                    return beanMetaData.PrimaryKeySize;
            }
        }

        public string GetMyKey(int index)
        {
            if(myKeys.Length > 0)
                return myKeys[index];
            else
                return beanMetaData.GetPrimaryKey(index);
        }

        public string GetYourKey(int index)
        {
            if(yourKeys.Length > 0)
                return yourKeys[index];
            else
                return beanMetaData.GetPrimaryKey(index);
        }

        public bool IsYourKey(string columnName)
        {
            for(int i = 0; i < KeySize; ++i)
            {
                if(string.Compare(columnName, GetYourKey(i), true) == 0)
                    return true;
            }
            return false;
        }

        public IBeanMetaData BeanMetaData
        {
            get
            {
                return beanMetaData;
            }
        }

        #endregion

    }
}
