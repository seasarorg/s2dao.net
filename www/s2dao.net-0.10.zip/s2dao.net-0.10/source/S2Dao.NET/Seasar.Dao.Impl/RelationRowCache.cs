using System;
using System.Collections;

namespace Seasar.Dao.Impl
{
    public class RelationRowCache
    {
        private ArrayList rowMapList;

        public RelationRowCache(int size)
        {
            rowMapList = new ArrayList();
            for(int i = 0; i < size; ++i)
                rowMapList.Add(new Hashtable());
        }

        public object GetRelationRow(int relno, RelationKey key)
        {
            return GetRowMap(relno)[key];
        }

        public void AddRelationRow(int relno, RelationKey key, object row)
        {
            GetRowMap(relno)[key] = row;
        }

        protected Hashtable GetRowMap(int relno)
        {
            return (Hashtable) rowMapList[relno];
        }
    }
}
