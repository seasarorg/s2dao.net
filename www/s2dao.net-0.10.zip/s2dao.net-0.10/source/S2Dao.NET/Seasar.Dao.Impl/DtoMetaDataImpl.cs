using System;
using System.Collections;
using System.Reflection;
using Seasar.Dao.Attrs;
using Seasar.Extension.ADO;
using Seasar.Extension.ADO.Impl;
using Seasar.Extension.ADO.Types;
using Seasar.Framework.Beans;

namespace Seasar.Dao.Impl
{
    public class DtoMetaDataImpl : IDtoMetaData
    {
        private Type beanType;
        private Hashtable propertyTypes = new Hashtable(
            CaseInsensitiveHashCodeProvider.Default, CaseInsensitiveComparer.Default);

        protected DtoMetaDataImpl()
        {
        }

        public DtoMetaDataImpl(Type beanType)
        {
            this.beanType = beanType;
            SetupPropertyType();
        }

        #region IDtoMetaData �����o

        public Type BeanType
        {
            get
            {
                return beanType;
            }
            set
            {
                beanType = value; 
            }
        }

        public int PropertyTypeSize
        {
            get
            {
                return propertyTypes.Count;
            }
        }

        public Seasar.Extension.ADO.IPropertyType GetPropertyType(int index)
        {
            IEnumerator enu = propertyTypes.Keys.GetEnumerator();
            for(int i = -1; i < index; ++i) enu.MoveNext();
            return (IPropertyType) propertyTypes[enu.Current];
        }

        public IPropertyType GetPropertyType(string propertyName)
        {
            IPropertyType propertyType = (IPropertyType) propertyTypes[propertyName];
            if(propertyType == null)
                throw new PropertyNotFoundRuntimeException(beanType, propertyName);
            return propertyType;
        }

        public bool HasPropertyType(string propertyName)
        {
            return propertyTypes.Contains(propertyName);
        }

        #endregion

        protected void SetupPropertyType()
        {
            foreach(PropertyInfo pi in beanType.GetProperties())
            {
                IPropertyType pt = CreatePropertyType(pi);
                AddPropertyType(pt);
            }
        }

        protected IPropertyType CreatePropertyType(PropertyInfo pi)
        {
            ColumnAttribute attr = AttributeUtil.GetColumnAttribute(pi);
            string columnName = pi.Name;
            if(attr != null) columnName = attr.ColumnName;
            IValueType valueType = ValueTypes.GetValueType(pi.PropertyType);
            IPropertyType pt = new PropertyTypeImpl(pi, valueType, columnName);
            return pt;
        }

        protected void AddPropertyType(IPropertyType propertyType)
        {
            propertyTypes.Add(propertyType.PropertyName, propertyType);
        }
    }
}
