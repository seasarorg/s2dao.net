using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class UpdateAutoHandler : AbstractAutoHandler
    {
        public UpdateAutoHandler(IDataSource dataSource, ICommandFactory commandFactory,
            IBeanMetaData beanMetaData, IPropertyType[] propertyTypes)
            : base(dataSource, commandFactory, beanMetaData, propertyTypes)
        {
        }

        protected override void SetupBindVariables(object bean)
        {
            SetupUpdateBindVariables(bean);
        }

        protected override void PostUpdateBean(object bean)
        {
            UpdateVersionNoIfNeed(bean);
            UpdateTimestampIfNeed(bean);
        }
    }
}
