using System;
using Seasar.Dao.Context;
using Seasar.Dao.Parser;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public abstract class AbstractDynamicCommand : AbstractSqlCommand
    {
        private INode rootNode;
        private string[] argNames = new string[0];
        private Type[] argTypes = new Type[0];

        public AbstractDynamicCommand(IDataSource dataSource, ICommandFactory commandFactory)
            : base(dataSource, commandFactory)
        {
        }

        public override string Sql
        {
            set 
            {
                base.Sql = value;
                rootNode = new SqlParserImpl(value).Parse();
            }
            get
            {
                return base.Sql;
            }
        }

        public string[] ArgNames
        {
            get { return argNames; }
            set { argNames = value; }
        }

        public Type[] ArgTypes
        {
            get { return argTypes; }
            set { argTypes = value; }
        }

        protected ICommandContext Apply(object[] args)
        {
            ICommandContext ctx = CreateCommandContext(args);
            rootNode.Accept(ctx);
            return ctx;
        }

        protected ICommandContext CreateCommandContext(object[] args)
        {
            ICommandContext ctx = GetCommandContext();
            if(args != null)
            {
                for(int i = 0; i < args.Length; ++i)
                {
                    Type argType = null;
                    if(args[i] != null)
                    {
                        if(i < argTypes.Length)
                            argType = argTypes[i];
                        else if (args[i] != null)
                            argType = args[i].GetType();
                    }
                    if(i < argNames.Length)
                        ctx.AddArg(argNames[i], args[i], argType);
                    else
                        ctx.AddArg("$" + (i + 1), args[i], argType);
                }
            }
            return ctx;
        }

        private ICommandContext GetCommandContext()
        {
            // �b��I��
            return new SqlClientCommandContextImpl();
        }
    }
}
