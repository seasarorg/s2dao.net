using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class InsertAutoStaticCommand : AbstractAutoStaticCommand
    {
        public InsertAutoStaticCommand(IDataSource dataSource, ICommandFactory commandFactory,
            IBeanMetaData beanMetaData, string[] propertyNames)
            : base(dataSource, commandFactory, beanMetaData, propertyNames)
        {
        }

        protected override AbstractAutoHandler CreateAutoHandler()
        {
            return new InsertAutoHandler(DataSource, CommandFactory,
                BeanMetaData, PropertyTypes);
        }

        protected override void SetupSql()
        {
            SetupInsertSql();
        }

        protected override void SetupPropertyTypes(string[] propertyNames)
        {
            SetupInsertPropertyTypes(propertyNames);
        }
    }
}
