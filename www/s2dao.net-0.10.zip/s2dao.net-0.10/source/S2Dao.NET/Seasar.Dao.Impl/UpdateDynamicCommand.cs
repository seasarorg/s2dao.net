using System;
using Seasar.Extension.ADO;
using Seasar.Extension.ADO.Impl;

namespace Seasar.Dao.Impl
{
    /// <summary>
    /// UpdateDynamicCommand �̊T�v�̐����ł��B
    /// </summary>
    public class UpdateDynamicCommand : AbstractDynamicCommand
    {
        public UpdateDynamicCommand(IDataSource dataSource, ICommandFactory commandFactory)
            : base(dataSource, commandFactory)
        {
        }

        public override object Execute(object[] args)
        {
            ICommandContext ctx = Apply(args);
            BasicUpdateHandler updateHandler = new BasicUpdateHandler(
                DataSource, ctx.Sql, CommandFactory);
            return updateHandler.Execute(ctx.BindVariables,
                ctx.BindVariableTypes, ctx.BindVariableNames);
        }
    }
}
