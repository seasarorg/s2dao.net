using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class DeleteAutoStaticCommand : AbstractAutoStaticCommand
    {
        public DeleteAutoStaticCommand(IDataSource dataSource, ICommandFactory commandFactory,
            IBeanMetaData beanMetaData, string[] propertyNames)
            : base(dataSource, commandFactory, beanMetaData, propertyNames)
        {
        }

        protected override AbstractAutoHandler CreateAutoHandler()
        {
            return new DeleteAutoHandler(DataSource, CommandFactory,
                BeanMetaData, PropertyTypes);
        }

        protected override void SetupSql()
        {
            SetupDeleteSql();
        }

        protected override void SetupPropertyTypes(string[] propertyNames)
        {
            SetupDeletePropertyTypes(propertyNames);
        }
    }
}
