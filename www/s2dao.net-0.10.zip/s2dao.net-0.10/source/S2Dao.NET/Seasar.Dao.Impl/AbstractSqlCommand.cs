using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public abstract class AbstractSqlCommand : ISqlCommand
    {
        private IDataSource dataSource;
        private ICommandFactory commandFactory;
        private string sql;
        private Type notSingleRowUpdatedExceptionType;

        public AbstractSqlCommand(IDataSource dataSource,
            ICommandFactory commandFactory)
        {
            this.dataSource = dataSource;
            this.commandFactory = commandFactory;
        }

        public IDataSource DataSource
        {
            get { return dataSource; }
        }

        public ICommandFactory CommandFactory
        {
            get { return commandFactory; }
        }

        public virtual string Sql
        {
            get { return sql; }
            set { sql = value; }
        }

        public Type NotSingleRowUpdatedExceptionType
        {
            get { return notSingleRowUpdatedExceptionType; }
            set { notSingleRowUpdatedExceptionType = value; }
        }

        #region ISqlCommand �����o

        public abstract object Execute(object[] args);

        #endregion
    }
}
