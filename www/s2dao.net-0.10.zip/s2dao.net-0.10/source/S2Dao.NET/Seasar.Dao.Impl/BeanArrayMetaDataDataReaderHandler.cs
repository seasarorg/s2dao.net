using System;
using System.Collections;

namespace Seasar.Dao.Impl
{
    public class BeanArrayMetaDataDataReaderHandler
        : BeanListMetaDataDataReaderHandler
    {
        public BeanArrayMetaDataDataReaderHandler(IBeanMetaData beanMetaData)
            : base(beanMetaData)
        {
        }

        public override object Handle(System.Data.IDataReader dataReader)
        {
            ArrayList list = (ArrayList) base.Handle(dataReader);
            return list.ToArray(BeanMetaData.BeanType);
        }

    }
}
