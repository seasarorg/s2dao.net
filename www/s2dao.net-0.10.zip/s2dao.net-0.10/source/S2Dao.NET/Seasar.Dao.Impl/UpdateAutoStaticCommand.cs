using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class UpdateAutoStaticCommand : AbstractAutoStaticCommand
    {
        public UpdateAutoStaticCommand(IDataSource dataSource, ICommandFactory commandFactory,
            IBeanMetaData beanMetaData, string[] propertyNames)
            : base(dataSource, commandFactory, beanMetaData, propertyNames)
        {
        }

        protected override AbstractAutoHandler CreateAutoHandler()
        {
            return new UpdateAutoHandler(DataSource, CommandFactory,
                BeanMetaData, PropertyTypes);
        }

        protected override void SetupSql()
        {
            SetupUpdateSql();
        }

        protected override void SetupPropertyTypes(string[] propertyNames)
        {
            SetupUpdatePropertyTypes(propertyNames);
        }
    }
}
