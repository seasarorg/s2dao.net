using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class DeleteAutoHandler : AbstractAutoHandler
    {
        public DeleteAutoHandler(IDataSource dataSource, ICommandFactory commandFactory,
            IBeanMetaData beanMetaData, IPropertyType[] propertyTypes)
            : base(dataSource, commandFactory, beanMetaData, propertyTypes)
        {
        }

        protected override void SetupBindVariables(object bean)
        {
            SetupDeleteBindVariables(bean);
        }
    }
}
