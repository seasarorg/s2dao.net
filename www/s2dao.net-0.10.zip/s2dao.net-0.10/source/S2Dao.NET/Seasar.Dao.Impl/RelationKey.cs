using System;

namespace Seasar.Dao.Impl
{
    public sealed class RelationKey
    {
        private object[] values;
        private int hashCode;

        public RelationKey(object[] values)
        {
            this.values = values;
            foreach(object value in values)
                hashCode += value.GetHashCode();
        }

        public object[] Values
        {
            get { return values; }
        }

        public override int GetHashCode()
        {
            return hashCode;
        }

        public override bool Equals(object obj)
        {
            if(!(obj is RelationKey)) return false;
            object[] otherValues = ((RelationKey) obj).values;
            if(values.Length != otherValues.Length) return false;
            for(int i = 0; i < values.Length; ++i)
            {
                if(!values[i].Equals(otherValues[i])) return false;
            }
            return true;
        }

    }
}
