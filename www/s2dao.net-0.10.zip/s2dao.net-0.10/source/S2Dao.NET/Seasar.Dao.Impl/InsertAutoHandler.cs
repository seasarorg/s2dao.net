using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class InsertAutoHandler : AbstractAutoHandler
    {
        public InsertAutoHandler(IDataSource dataSource, ICommandFactory commandFactory,
            IBeanMetaData beanMetaData, IPropertyType[] propertyTypes)
            : base(dataSource, commandFactory, beanMetaData, propertyTypes)
        {
        }

        protected override void SetupBindVariables(object bean)
        {
            SetupInsertBindVariables(bean);
        }

        protected override void PreUpdateBean(object bean)
        {
            IIdentifierGenerator generator = BeanMetaData.IdentifierGenerator;
            if(generator.IsSelfGenerate)
                generator.SetIdentifier(bean, DataSource);
        }

        protected override void PostUpdateBean(object bean)
        {
            IIdentifierGenerator generator = BeanMetaData.IdentifierGenerator;
            if(!generator.IsSelfGenerate)
                generator.SetIdentifier(bean, DataSource);
            UpdateVersionNoIfNeed(bean);
            UpdateTimestampIfNeed(bean);
        }
    }
}
