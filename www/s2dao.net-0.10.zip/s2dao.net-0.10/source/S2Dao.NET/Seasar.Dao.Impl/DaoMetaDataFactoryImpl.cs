using System;
using System.Collections;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Impl
{
    public class DaoMetaDataFactoryImpl : IDaoMetaDataFactory
    {
        private Hashtable daoMetaDataCache = new Hashtable();
        private IDataSource dataSource;
        private ICommandFactory commandFactory;
        private IDataReaderFactory dataReaderFactory;

        public DaoMetaDataFactoryImpl(IDataSource dataSource,
            ICommandFactory commandFactory, IDataReaderFactory dataReaderFactory)
        {
            this.dataSource = dataSource;
            this.commandFactory = commandFactory;
            this.dataReaderFactory = dataReaderFactory;
        }

        #region IDaoMetaDataFactory �����o

        public IDaoMetaData GetDaoMetaData(Type daoType)
        {
            lock(this)
            {
                string key = daoType.FullName;
                IDaoMetaData dmd = (IDaoMetaData) daoMetaDataCache[key];
                if(dmd != null) return dmd;
                dmd = new DaoMetaDataImpl(daoType, dataSource, commandFactory,
                    dataReaderFactory);
                daoMetaDataCache[key] = dmd;
                return dmd;
            }
        }

        #endregion
    }
}
