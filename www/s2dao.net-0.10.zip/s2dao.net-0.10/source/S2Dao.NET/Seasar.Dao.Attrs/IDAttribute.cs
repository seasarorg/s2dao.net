using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Property)]
    public class IDAttribute : Attribute
    {
        private string id;
        private string sequenceName;

        public IDAttribute(string id)
        {
            this.id = id;
        }

        public string ID
        {
            get { return id; }
        }

        public string SequenceName
        {
            get { return sequenceName; }
            set { sequenceName = value; }
        }
    }
}
