using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Class)]
    public class TimestampPropertyAttribute : Attribute
    {
        private string propertyName;

        public TimestampPropertyAttribute(string propertyName)
        {
            this.propertyName = propertyName;
        }

        public string PropertyName
        {
            get { return propertyName; }
        }
    }
}
