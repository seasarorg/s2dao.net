using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Class)]
    public class VersionNoPropertyAttribute : Attribute
    {
        private string propertyName;

        public VersionNoPropertyAttribute(string propertyName)
        {
            this.propertyName = propertyName;
        }

        public string PropertyName
        {
            get { return propertyName; }
        }
    }
}
