using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class NoPersistentPropsAttribute : Attribute
    {
        private string[] props;

        public NoPersistentPropsAttribute(params string[] props)
        {
            this.props = props;
        }

        public string[] Props
        {
            get { return props; }
        }
    }
}
