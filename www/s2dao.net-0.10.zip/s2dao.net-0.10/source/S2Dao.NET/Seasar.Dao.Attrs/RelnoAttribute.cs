using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Property)]
    public class RelnoAttribute : Attribute
    {
        private int relno;

        public RelnoAttribute(int relno)
        {
            this.relno = relno;
        }

        public int Relno
        {
            get { return relno; }
        }
    }
}
