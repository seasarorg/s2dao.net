using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Method)]
    public class QueryAttribute : Attribute
    {
        private string query;

        public QueryAttribute(string query)
        {
            this.query = query;
        }

        public string Query
        {
            get { return query; }
        }
    }
}
