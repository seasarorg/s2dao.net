using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public class SqlAttribute : Attribute
    {
        private string sql;
        private KindOfDbms dbms = KindOfDbms.None;

        public SqlAttribute(string sql)
        {
            this.sql = sql;
        }

        public SqlAttribute(string sql, KindOfDbms dbms)
            : this(sql)
        {
            this.dbms = dbms;
        }

        public string Sql
        {
            get { return sql; }
        }

        public KindOfDbms Dbms
        {
            get { return dbms; }
        }
    }
}
