using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Property)]
    public class RelkeysAttribute : Attribute
    {
        private string relkeys;

        public RelkeysAttribute(string relkeys)
        {
            this.relkeys = relkeys;
        }

        public string Relkeys
        {
            get { return relkeys; }
        }
    }
}
