using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Interface)]
    public class BeanAttribute : Attribute
    {
        private Type beanType;

        public BeanAttribute(Type beanType)
        {
            this.beanType = beanType;
        }

        public Type BeanType
        {
            get { return beanType; }
        }
    }
}
