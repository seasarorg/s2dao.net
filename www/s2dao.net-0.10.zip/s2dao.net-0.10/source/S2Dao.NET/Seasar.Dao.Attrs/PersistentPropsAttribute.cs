using System;

namespace Seasar.Dao.Attrs
{
    [AttributeUsage(AttributeTargets.Method)]
    public class PersistentPropsAttribute : Attribute
    {
        private string[] props;

        public PersistentPropsAttribute(params string[] props)
        {
            this.props = props;
        }

        public string[] Props
        {
            get { return props; }
        }
    }
}
