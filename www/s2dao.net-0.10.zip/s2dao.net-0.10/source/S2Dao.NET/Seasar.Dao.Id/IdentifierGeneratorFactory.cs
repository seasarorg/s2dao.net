using System;
using System.Collections;
using System.Reflection;
using Seasar.Dao.Attrs;
using Seasar.Framework.Util;

namespace Seasar.Dao.Id
{
    /// <summary>
    /// IdentifierGeneratorFactory �̊T�v�̐����ł��B
    /// </summary>
    public class IdentifierGeneratorFactory
    {
        private static Hashtable generatorTypes = new Hashtable();

        static IdentifierGeneratorFactory()
        {
            AddIdentifierGeneratorType("assigned", typeof(AssignedIdentifierGenerator));
            AddIdentifierGeneratorType("identity", typeof(IdentityIdentifierGenerator));
            AddIdentifierGeneratorType("sequence", typeof(SequenceIdentifierGenerator));
        }

        private IdentifierGeneratorFactory()
        {
        }

        public static void AddIdentifierGeneratorType(string name, Type type)
        {
            generatorTypes[name] = type;
        }

        public static IIdentifierGenerator CreateIdentifierGenerator(
            string propertyName, IDbms dbms)
        {
            return CreateIdentifierGenerator(propertyName, dbms, null);
        }

        public static IIdentifierGenerator CreateIdentifierGenerator(
            string propertyName, IDbms dbms, IDAttribute idAttr)
        {
            if(idAttr == null) 
                return new AssignedIdentifierGenerator(propertyName, dbms);
            Type type = GetGeneratorType(idAttr.ID);
            IIdentifierGenerator generator = CreateIdentifierGenerator(type, propertyName, dbms);
            if(idAttr.SequenceName != null)
                SetProperty(generator, "SequenceName", idAttr.SequenceName);
            return generator;
        }

        protected static Type GetGeneratorType(string name)
        {
            Type type = (Type) generatorTypes[name];
            if(type != null) return type;
            return ClassUtil.ForName(name, AppDomain.CurrentDomain.GetAssemblies());
        }

        protected static IIdentifierGenerator CreateIdentifierGenerator(
            Type type, string propertyName, IDbms dbms)
        {
            ConstructorInfo constructor = 
                ClassUtil.GetConstructorInfo(type, new Type[] { typeof(string), typeof(IDbms) });
            return (IIdentifierGenerator) 
                ConstructorUtil.NewInstance(constructor, new object[] { propertyName, dbms });
        }

        protected static void SetProperty(IIdentifierGenerator generator, string propertyName, string value)
        {
            PropertyInfo property = generator.GetType().GetProperty(propertyName);
            property.SetValue(generator, value, null);
        }
    }
}
