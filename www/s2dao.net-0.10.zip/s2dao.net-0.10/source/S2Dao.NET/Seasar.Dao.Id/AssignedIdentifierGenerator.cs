using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Id
{
    public class AssignedIdentifierGenerator : AbstractIdentifierGenerator
    {
        public AssignedIdentifierGenerator(string propertyName, IDbms dbms)
            : base(propertyName, dbms)
        {
        }

        public override void SetIdentifier(object bean, IDataSource ds)
        {
        }

        public override bool IsSelfGenerate
        {
            get { return true; }
        }
    }
}
