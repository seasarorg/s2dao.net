using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Id
{
    /// <summary>
    /// IdentityIdentifierGenerator �̊T�v�̐����ł��B
    /// </summary>
    public class IdentityIdentifierGenerator : AbstractIdentifierGenerator
    {
        public IdentityIdentifierGenerator(string propertyName, IDbms dbms)
            : base(propertyName, dbms)
        {
        }

        public override void SetIdentifier(object bean, IDataSource ds)
        {
            object value = ExecuteSql(ds, this.Dbms.IdentitySelectString, null);
            SetIdentifier(bean, value);
        }

        public override bool IsSelfGenerate
        {
            get { return false; }
        }
    }
}
