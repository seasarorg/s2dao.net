using System;
using Seasar.Extension.ADO;

namespace Seasar.Dao.Id
{
    public class SequenceIdentifierGenerator : AbstractIdentifierGenerator
    {
        private string sequenceName;

        public SequenceIdentifierGenerator(string propertyName, IDbms dbms)
            : base(propertyName, dbms)
        {
        }

        public string SequenceName
        {
            get { return this.sequenceName; }
            set { this.sequenceName = value; }
        }

        public override void SetIdentifier(object bean, IDataSource ds)
        {
            object value = ExecuteSql(ds, this.Dbms.GetSequenceNextValString(sequenceName), null);
            SetIdentifier(bean, value);
        }

        public override bool IsSelfGenerate
        {
            get { return true; }
        }

    }
}
