using System;
using System.Reflection;
using Seasar.Dao.Dbms;
using Seasar.Extension.ADO;
using Seasar.Extension.ADO.Impl;
using Seasar.Framework.Exceptions;

namespace Seasar.Dao.Id
{
    /// <summary>
    /// AbstractIdentifierGenerator �̊T�v�̐����ł��B
    /// </summary>
    public abstract class AbstractIdentifierGenerator : IIdentifierGenerator
    {
        private static IDataReaderHandler dataReaderHandler = new ObjectDataReaderHandler();
        private string propertyName;
        private IDbms dbms;

        public AbstractIdentifierGenerator(string propertyName, IDbms dbms)
        {
            this.propertyName = propertyName;
            this.dbms = dbms;
        }

        public string PropertyName
        {
            get { return this.propertyName; }
        }

        public IDbms Dbms
        {
            get { return this.dbms; }
        }

        protected object ExecuteSql(IDataSource ds, string sql, object[] args)
        {
            BasicSelectHandler handler = new BasicSelectHandler(ds, sql, dataReaderHandler);
            return handler.Execute(args);
        }

        protected void SetIdentifier(object bean, object value)
        {
            if(propertyName == null) throw new EmptyRuntimeException("propertyName");
            PropertyInfo propertyInfo = bean.GetType().GetProperty(propertyName);
            propertyInfo.SetValue(bean, value, null);
        }

        #region IIdentifierGenerator �����o

        public virtual bool IsSelfGenerate
        {
            get { throw new NotImplementedException(); }
        }

        public virtual void SetIdentifier(object bean, Seasar.Extension.ADO.IDataSource ds)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
