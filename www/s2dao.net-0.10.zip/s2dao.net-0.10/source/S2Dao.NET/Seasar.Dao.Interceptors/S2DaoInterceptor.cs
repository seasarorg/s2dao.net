using System;
using System.Reflection;
using Seasar.Framework.Aop.Interceptors;

namespace Seasar.Dao.Interceptors
{
    public class S2DaoInterceptor : AbstractInterceptor
    {
        private IDaoMetaDataFactory daoMetaDataFactory;

        public S2DaoInterceptor(IDaoMetaDataFactory daoMetaDataFactory)
        {
            this.daoMetaDataFactory = daoMetaDataFactory;
        }

        public override object Invoke(Seasar.Framework.Aop.IMethodInvocation invocation)
        {
            MethodBase method = invocation.Method;
            if(!method.IsAbstract) return invocation.Proceed();
            Type targetType = GetComponentDef(invocation).ComponentType;
            IDaoMetaData dmd = daoMetaDataFactory.GetDaoMetaData(targetType);
            ISqlCommand cmd = dmd.GetSqlCommand(method.Name);
            object ret = cmd.Execute(invocation.Arguments);
            
            Type retType = ((MethodInfo) method).ReturnType;
            if(typeof(IConvertible).IsAssignableFrom(retType))
            {
                if(ret == null) 
                {
                    if(!retType.Equals(typeof(string))) 
                        ret = Convert.ChangeType(decimal.Zero, retType);
                }
                else
                {
                    ret = Convert.ChangeType(ret, retType);
                }
            }
            return ret;
        }

    }
}
