using System;
using System.Collections;

namespace Seasar.Framework.Util
{
    public class CaseInsentiveSet : CollectionBase, IList
    {
        public CaseInsentiveSet()
        {
        }

        bool IList.Contains(object value)
        {
            return Contains(value);
        }

        int IList.Add(object value)
        {
            if(Contains(value))
                return -1;
            else
                return InnerList.Add(value);
        }

        private bool Contains(object value)
        {
            InnerList.Sort(CaseInsensitiveComparer.Default);
            return InnerList.BinarySearch(value, CaseInsensitiveComparer.Default) >= 0;
        }
    }
}
