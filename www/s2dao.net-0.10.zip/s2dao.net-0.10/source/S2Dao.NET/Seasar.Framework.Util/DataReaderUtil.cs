using System;
using System.Data;
using Seasar.Framework.Exceptions;

namespace Seasar.Framework.Util
{
    public sealed class DataReaderUtil
    {
        private DataReaderUtil()
        {
        }

        public static void Close(IDataReader dataReader)
        {
            if(dataReader == null) return;
            try
            {
                dataReader.Close();
            }
            catch(Exception ex)
            {
                throw new SQLRuntimeException(ex);
            }
        }
    }
}
