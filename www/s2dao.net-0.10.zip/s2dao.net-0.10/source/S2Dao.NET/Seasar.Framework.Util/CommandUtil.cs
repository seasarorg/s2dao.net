using System;
using System.Data;
using Seasar.Extension.ADO;
using Seasar.Framework.Exceptions;

namespace Seasar.Framework.Util
{
    public sealed class CommandUtil
    {
        private CommandUtil()
        {
        }

        public static void Close(IDbCommand cmd)
        {
            if(cmd == null) return;
            try
            {
                cmd.Dispose();
            }
            catch(Exception ex)
            {
                throw new SQLRuntimeException(ex);
            }
        }

        public static IDataReader ExecuteReader(IDataSource dataSource, IDbCommand cmd)
        {
            try
            {
                DataSourceUtil.SetTransaction(dataSource, cmd);
                return cmd.ExecuteReader();
            }
            catch(Exception ex)
            {
                throw new SQLRuntimeException(ex);
            }
        }

        public static int ExecuteNonQuery(IDataSource dataSource, IDbCommand cmd)
        {
            try
            {
                DataSourceUtil.SetTransaction(dataSource, cmd); 
                return cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                throw new SQLRuntimeException(ex);
            }
        }

        public static object ExecuteScalar(IDataSource dataSource, IDbCommand cmd)
        {
            try
            {
                DataSourceUtil.SetTransaction(dataSource, cmd);
                return cmd.ExecuteScalar();
            }
            catch(Exception ex)
            {
                throw new SQLRuntimeException(ex);
            }
        }

    }
}
