using System;
using System.Data;
using System.Data.SqlClient;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO.Types
{
    public abstract class BaseValueType
    {
        private IDataSource dataSource;

        public BaseValueType(IDataSource dataSource)
        {
            this.dataSource = dataSource;
        }

        public void BindValue(System.Data.IDbCommand cmd, string columnName, object value, DbType dbType)
        {
            if(dataSource.GetConnection() is SqlConnection) columnName = "@" + columnName;
            IDataParameter parameter = dataSource.GetParameter(columnName, dbType);
            parameter.Value = value == null ? DBNull.Value : value;
            cmd.Parameters.Add(parameter);
        }
    }
}
