using System;
using System.Data;
using System.Data.SqlClient;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO.Types
{
    public class StringType : BaseValueType, IValueType
    {

        public StringType(IDataSource dataSource)
            : base(dataSource)
        {
        }

        #region IValueType �����o

        public object GetValue(System.Data.IDataReader reader, int index)
        {
            return reader.GetString(index);
        }

        object Seasar.Extension.ADO.IValueType.GetValue(System.Data.IDataReader reader, string columnName)
        {
            return (string) reader[columnName];
        }

        public void BindValue(System.Data.IDbCommand cmd, string columnName, object value)
        {
            BindValue(cmd, columnName, value, DbType.String);
        }

        #endregion
    }
}
