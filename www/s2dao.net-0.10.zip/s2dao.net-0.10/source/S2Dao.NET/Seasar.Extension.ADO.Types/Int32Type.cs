using System;
using System.Data;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO.Types
{
    public class Int32Type :BaseValueType, IValueType
    {
        public Int32Type(IDataSource dataSource)
            : base(dataSource)
        {
        }

        #region IValueType �����o

        public object GetValue(System.Data.IDataReader reader, int index)
        {
            return Convert.ToInt32(reader.GetValue(index));
        }

        object Seasar.Extension.ADO.IValueType.GetValue(System.Data.IDataReader reader, string columnName)
        {
            return Convert.ToInt32(reader[columnName]);
        }

        public void BindValue(System.Data.IDbCommand cmd, string columnName, object value)
        {
            BindValue(cmd, columnName, value, DbType.Int32);
        }

        #endregion
    }
}
