using System;
using System.Data;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO.Types
{
    public class BinaryType : BaseValueType, IValueType
    {
        public BinaryType(IDataSource dataSource)
            : base(dataSource)
        {
        }

        #region IValueType �����o

        public object GetValue(IDataReader reader, int index)
        {
            return (byte[]) reader[index];
        }

        object Seasar.Extension.ADO.IValueType.GetValue(IDataReader reader, string columnName)
        {
            return (byte[]) reader[columnName];
        }

        public void BindValue(IDbCommand cmd, string columnName, object value)
        {
            BindValue(cmd, columnName, value, DbType.Binary);
        }

        #endregion
    }
}
