using System;
using System.Data;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO.Types
{
    public class Int64Type :BaseValueType, IValueType
    {
        public Int64Type(IDataSource dataSource)
            : base(dataSource)
        {
        }

        #region IValueType �����o

        public object GetValue(System.Data.IDataReader reader, int index)
        {
            return Convert.ToInt64(reader.GetValue(index));
        }

        object Seasar.Extension.ADO.IValueType.GetValue(System.Data.IDataReader reader, string columnName)
        {
            return Convert.ToInt64(reader[columnName]);
        }

        public void BindValue(System.Data.IDbCommand cmd, string columnName, object value)
        {
            BindValue(cmd, columnName, value, DbType.Int64);
        }

        #endregion
    }
}
