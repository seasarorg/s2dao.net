using System;
using System.Data;
using Seasar.Extension.ADO;

namespace Seasar.Extension.ADO.Types
{
    public class DecimalType :BaseValueType, IValueType
    {
        public DecimalType(IDataSource dataSource)
            : base(dataSource)
        {
        }

        #region IValueType �����o

        public object GetValue(IDataReader reader, int index)
        {
            return Convert.ToDecimal(reader.GetValue(index));
        }

        object Seasar.Extension.ADO.IValueType.GetValue(IDataReader reader, string columnName)
        {
            return Convert.ToDecimal(reader[columnName]);
        }

        public void BindValue(IDbCommand cmd, string columnName, object value)
        {
            BindValue(cmd, columnName, value, DbType.Decimal);
        }

        #endregion
    }
}
