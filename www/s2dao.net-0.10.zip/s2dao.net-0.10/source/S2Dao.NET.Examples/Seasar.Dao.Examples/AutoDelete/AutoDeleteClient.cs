using System;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Dao.Examples.AutoDelete
{
    /// <summary>
    /// Delete�����������̃T���v�������s���܂��B
    /// </summary>
    public class AutoDeleteClient
    {
        private const string PATH = "Seasar.Dao.Examples/AutoDelete/AutoDelete.dicon";

        public void Main()
        {
            IS2Container container = S2ContainerFactory.Create(PATH);
            IAutoDeleteLogic logic = (IAutoDeleteLogic) container.GetComponent(typeof(IAutoDeleteLogic));

            try
            {
                logic.TestAutoDelete();
            }
            catch(ForCleanupException){}
        }
    }
}
