select ename from emp
where empno=/*empno*/20