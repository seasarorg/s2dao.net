using System;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Dao.Examples.NoPersistentPropsAttr
{
    /// <summary>
    /// NoPersistentProps�����̃T���v�������s���܂��B
    /// </summary>
    public class NoPersistentPropsAttrClient
    {
        private const string PATH = 
            "Seasar.Dao.Examples/NoPersistentPropsAttr/NoPersistentPropsAttr.dicon";

        public void Main()
        {
            IS2Container container = S2ContainerFactory.Create(PATH);
            INoPersistentPropsAttrLogic logic = (INoPersistentPropsAttrLogic) 
                container.GetComponent(typeof(INoPersistentPropsAttrLogic));

            try
            {
                logic.TestNoPersistentPropsAttr();
            }
            catch(ForCleanupException){}
        }
    }
}
