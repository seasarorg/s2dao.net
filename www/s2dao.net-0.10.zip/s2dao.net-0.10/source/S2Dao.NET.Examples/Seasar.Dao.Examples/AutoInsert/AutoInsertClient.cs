using System;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Dao.Examples.AutoInsert
{
    /// <summary>
    /// Insert�����������̃T���v�������s���܂��B
    /// </summary>
    public class AutoInsertClient
    {
        private const string PATH = "Seasar.Dao.Examples/AutoInsert/AutoInsert.dicon";

        public void Main()
        {
            IS2Container container = S2ContainerFactory.Create(PATH);
            IAutoInsertLogic logic = (IAutoInsertLogic) container.GetComponent(typeof(IAutoInsertLogic));

            try
            {
                logic.TestAutoInsert();
            }
            catch(ForCleanupException){}
        }
    }
}
