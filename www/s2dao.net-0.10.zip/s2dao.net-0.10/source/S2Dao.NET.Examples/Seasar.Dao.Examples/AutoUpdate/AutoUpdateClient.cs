using System;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Dao.Examples.AutoUpdate
{
    /// <summary>
    /// Update�����������̃T���v�������s���܂��B
    /// </summary>
    public class AutoUpdateClient
    {
        private const string PATH = "Seasar.Dao.Examples/AutoUpdate/AutoUpdate.dicon";

        public void Main()
        {
            IS2Container container = S2ContainerFactory.Create(PATH);
            IAutoUpdateLogic logic = (IAutoUpdateLogic) container.GetComponent(typeof(IAutoUpdateLogic));

            try
            {
                logic.TestAutoUpdate();
            }
            catch(ForCleanupException){}
        }
    }
}
