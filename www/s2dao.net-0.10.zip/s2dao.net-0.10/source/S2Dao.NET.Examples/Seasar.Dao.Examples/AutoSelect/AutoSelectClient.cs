using System;
using System.Collections;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Dao.Examples.AutoSelect
{
    /// <summary>
    /// Select�����������̃T���v�������s���܂��B
    /// </summary>
    public class AutoSelectClient
    {
        private const string PATH = "Seasar.Dao.Examples/AutoSelect/AutoSelect.dicon";

        public void Main()
        {
            IS2Container container = S2ContainerFactory.Create(PATH);
            IEmployeeDao employeeDao = (IEmployeeDao) container.GetComponent(typeof(IEmployeeDao));

            // �S�Ă̏]�ƈ����擾
            IList employeeList = employeeDao.GetAllList();

            IEnumerator employees = employeeList.GetEnumerator();
            Console.WriteLine("/** �S�Ă̏]�ƈ��̃��X�g **/");
            while(employees.MoveNext())
            {
                Console.WriteLine(((Employee) employees.Current).ToString());
            }
        }
    }
}
