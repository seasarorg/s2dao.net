using System;
using System.Collections;
using Seasar.Dao.Attrs;

namespace Seasar.Dao.Examples.AutoSelect
{
    [Bean(typeof(Employee))]
    public interface IEmployeeDao
    {
        /// <summary>
        /// �S�Ă̏]�ƈ����擾���܂��B
        /// </summary>
        /// <returns>Employee�̃��X�g</returns>
        IList GetAllList();
    }
}
