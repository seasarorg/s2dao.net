using System;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Dao.Examples.PersistentPropsAttr
{
    /// <summary>
    /// PersistentProps�����̃T���v�������s���܂��B
    /// </summary>
    public class PersistentPropsAttrClient
    {
        private const string PATH = 
            "Seasar.Dao.Examples/PersistentPropsAttr/PersistentPropsAttr.dicon";

        public void Main()
        {
            IS2Container container = S2ContainerFactory.Create(PATH);
            IPersistentPropsAttrLogic logic = (IPersistentPropsAttrLogic) 
                container.GetComponent(typeof(IPersistentPropsAttrLogic));

            try
            {
                logic.TestPersistentPropsAttr();
            }
            catch(ForCleanupException){}
        }
    }
}
