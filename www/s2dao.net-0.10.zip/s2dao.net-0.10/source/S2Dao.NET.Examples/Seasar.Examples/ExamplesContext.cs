using System;

using System.Windows.Forms;

namespace Seasar.Examples
{
    /// <summary>
    /// �f�����s���ׂɕK�v�ƂȂ�n���h���̊i�[�̈�
    /// </summary>
    public class ExamplesContext
    {
        public event ResultViewChangedEventHandler ResultViewChanged;
        public ExamplesContext()
        {
        }

        public Control ResultView 
        {
            set 
            {
                ResultViewChanged(value);
            }
        }

    }
    public delegate void ResultViewChangedEventHandler(Control ctrl);
}
