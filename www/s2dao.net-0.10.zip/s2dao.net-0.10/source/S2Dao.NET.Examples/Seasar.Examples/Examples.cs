using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

using log4net;
using log4net.Config;
using log4net.Util;

using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;

namespace Seasar.Examples
{
    /// <summary>
    /// Examples���u�[�g�X�g���b�v����N���X�ł��B
    /// </summary>
    public class Examples
    {
        public Examples()
        {
        }

        /// <summary>
        /// �A�v���P�[�V�����̃��C�� �G���g�� �|�C���g�ł��B
        /// </summary>
        [STAThread]
        static void Main() 
        {
            TextWriter Out = Console.Out;
            TextWriter Err = Console.Error;
            try 
            {
                // log4net�̏�����
                FileInfo info = new FileInfo(SystemInfo.AssemblyShortName(
                    Assembly.GetExecutingAssembly()) + ".exe.config");
                XmlConfigurator.Configure(LogManager.GetRepository(), info);
                
                SingletonS2ContainerFactory.Init();
                IS2Container container = SingletonS2ContainerFactory.Container;
                ExamplesExplorer de = container.GetComponent(typeof(ExamplesExplorer)) as ExamplesExplorer;
                if(de != null) 
                {
                    Application.Run(de);
                }
            } 
            catch(Exception e) 
            {
                Out.WriteLine(e.Message);
                Console.ReadLine();
            } 
            finally 
            {
                SingletonS2ContainerFactory.Destroy();
            }
        }
    }
}
