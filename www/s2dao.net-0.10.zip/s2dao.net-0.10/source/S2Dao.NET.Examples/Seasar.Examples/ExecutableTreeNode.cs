using System;
using System.Windows.Forms;

namespace Seasar.Examples
{
    /// <summary>
    /// ExecutableTreeNode �̊T�v�̐����ł��B
    /// </summary>
    public class ExecutableTreeNode : TreeNode
    {
        private IExamplesHandler examplesHandler;
        public ExecutableTreeNode(IExamplesHandler handler) : base(handler.Title)
        {
            this.examplesHandler = handler;
        }
        
        public IExamplesHandler ExamplesHandler 
        {
            get 
            {
                return this.examplesHandler;
            }
        }
    }
}
