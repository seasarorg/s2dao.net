using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Seasar.Extension.UI
{
    /// <summary>
    /// �e�L�X�g�{�b�N�X�ɁA������X�g���[���𗬂����ވׂ̃N���X�ł��B
    /// </summary>
    public class TextAppender : StringWriter
    {
        private delegate void WriteEventHandler(String s);

        private TextBoxBase textBox;
        private WriteEventHandler WriteEvent;

        public TextAppender(TextBoxBase textBox)
        {
            this.textBox = textBox;
            this.textBox.HandleCreated += new EventHandler(OnHandleCreated);
            this.textBox.HandleDestroyed += new EventHandler(OnHandleDestroyed);

            this.WriteEvent = new WriteEventHandler(BufferText);
        }

        private void OnHandleCreated(object sender, EventArgs e)
        {
            this.textBox.AppendText(base.ToString()); // ���Ƀo�b�t�@�����O����Ă��镶������������ށB
            this.WriteEvent = new WriteEventHandler(AppendText);
        }

        private void OnHandleDestroyed(object sender, EventArgs e)
        {
            this.WriteEvent = new WriteEventHandler(DoNothing);
        }

        public override void Write(String s)
        {
            this.WriteEvent(s);
        }

        private void BufferText(string s)
        {
            base.Write(s);
        }

        private void AppendText(string s)
        {
            this.textBox.AppendText(s);
        }

        private void DoNothing(string s)
        {
        }
        public override void WriteLine(string s)
        {
            Write(s + base.NewLine);
        }

        public override void Write(char c)
        {
            Write(c.ToString());
        }
    }
}
