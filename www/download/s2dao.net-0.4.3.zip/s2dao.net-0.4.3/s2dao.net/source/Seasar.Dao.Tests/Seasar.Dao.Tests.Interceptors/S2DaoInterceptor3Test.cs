#region Copyright
/*
 * Copyright 2005 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
#endregion

using System;
using System.Collections;
using System.IO;
using System.Reflection;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;
using Seasar.Extension.Unit;
using MbUnit.Framework;
using log4net;
using log4net.Config;
using log4net.Util;

namespace Seasar.Dao.Tests.Interceptors
{
    [TestFixture]
    public class S2DaoInterceptor3Test : S2TestCase
	{
        private IDepartmentAutoDao _dao = null;
        private ILog _log= LogManager.GetLogger(typeof(S2DaoInterceptor3Test));

        public S2DaoInterceptor3Test()
        {
            FileInfo info = new FileInfo(SystemInfo.AssemblyShortName(
                Assembly.GetExecutingAssembly()) + ".dll.config");
            XmlConfigurator.Configure(LogManager.GetRepository(), info);
        }

        [Test, S2(Tx.Rollback)]
        public void TestUpdate()
        {
	        Department department = new Department();
            department.Deptno = 10;
            Assert.AreEqual(1, _dao.Update(department));
        }

        [Test, S2(Tx.Rollback)]
        public void TestDelete()
        {
            Department department = new Department();
            department.Deptno = 10;
            Assert.AreEqual(1, _dao.Delete(department));
        }
    }
}
