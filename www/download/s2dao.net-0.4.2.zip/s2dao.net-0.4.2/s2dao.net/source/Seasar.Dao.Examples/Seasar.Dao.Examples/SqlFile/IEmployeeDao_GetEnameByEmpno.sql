select ename from emp2
where empno=/*empno*/20